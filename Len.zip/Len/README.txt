*List panel privat*
• 3GB = Rp.4000
• 4GB = Rp.5000
• 5GB = Rp.6000
• 6GB = Rp.8000
• 7GB = Rp.10000
• 8GB = Rp.12000
• 9GB = Rp.14000
• 10Gb = Rp.15000
• ∞/unlimited = Rp.15.000 

*List panel public*
•1gb = 1.000
•2gb = 2.000
•3gb = 3.000
•4gb = 4.000
•5gb = 5.000
•6gb = 6.000
•7gb = 7.000
•8gb = 8.000
•9gb = 9.000
•10gb = Rp.10.000
• ∞/unlimited = 14.000

wa2order  langsung pv : wa.me/6288213993436
wa1order  langsung pv : wa.me/6283119115977
wa3order  langsung pv : wa.me/67078862558
tele : t.me/zal_x_u
testi : https://t.me/testirizel
join saluran: https://whatsapp.com/channel/0029Vaw0AGCEQIarHspllG1i

© rizel-dev 2022-2025