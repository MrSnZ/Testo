/*
  >> https://whatsapp.com/channel/0029Vaw0AGCEQIarHspllG1i <<
*/
global.owner = ['6282224228796']
global.ownername = "Len"
global.connect = true // ubah ke false klo mau connect lewat qrcode 
global.antilink = false
global.autotyping = false

/*
  
  >> Payment <<
*/
global.dana = "+62 858-5714-42823"
global.gopay = "+62 858-5714-42823"
global.ovo = "+62 858-5714-42823"
global.qris = "XXXX"

/*
  >> Message <<
*/
global.mess = {
"ketua": " ⇝ Access Denied \nKhusus Owner",
"prem": "⇝ Access Denied \nBeli Akses Premium Di Owner",
"premium": "⇝ Access Denied \nBeli Akses Premium Di Owner",
"japost": " -- Format Japost Tidak Tersedia -- ",
"rekber": " -- List Rekber Tidak Tersedia -- ",
"owner": " ⇝ Access Denied \nKhusus Owner"
}

/*
  >> MISC <<
*/
global.tele = "t.me/ckckckck212"
global.tele2 = "t.me/ckckckck212"
global.waMe = "wa.me/6282224228796"
global.tutorialBot = "https://youtube.com/@odiffyx" // Untuk menggampangkan buyer awam saat beli panel 
global.versionofscript = "8.0"
global.url = "https://8030.us.kg/file/mdiumX2P8MQV.jpg" // buat banner
global.urlbanner = "https://8030.us.kg/file/mdiumX2P8MQV.jpg" // buat banner 2
global.url2 = "https://t.me/ckckckck212" // isi url bebas buat reply
global.packname = "Len" // sticker
global.author = "Pnya Len" // sticker
global.group = "https://chat.whatsapp.com/DfIqtuq08sUJXBzqXwAnlm" // isi group bebas lu
global.idCH = "120363363009408737@newsletter"
global.xchannel = {
	jid: '120363363009408737@newsletter'
	}
	