const chalk = require("chalk")
const fs = require("fs")

//owmner v card
//domain && apikey && capikey && egg sesuai panel klian ya
// subrek channel AlwaysAnan
global.owner = ['6285891373644'] //ur owner number
global.ownernomer = "6285891373644" //ur owner number2
global.ownername = "ᥴі𝗍rᥲᥲᶠᵃⁿⁿ💞" //ur owner name
global.ytname = "tt: Fan60hz_" //ur yt chanel name
global.socialm = "ig : FanCwoHyper" //ur github or insta name
global.location = "𝚓𝚊𝚔𝚜𝚎𝚕 𝚋𝚛𝚘𝚠" //ur location
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = '_' // isi dengan domain panel lu
global.apikey = '_' // Isi Apikey Plta Lu
global.capikey = '_' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

//new
global.ownergc = "ᥴі𝗍rᥲᥲᶠᵃⁿⁿ💞"
global.botname = "ᑲ᥆𝗍 ᥴrᥱᥲ𝗍 ⍴ᥲᥒᥱᥣ ᑲᥡ ᥴі𝗍rᥲᥲᶠᵃⁿⁿ💞"
global.ownerNumber = ["6285891373644@s.whatsapp.net"]
global.ownerweb = "https://youtube.com/@ᥴі𝗍rᥲᥲᶠᵃⁿⁿ💞"
global.themeemoji = '🪀'
global.wm = "tt: Fan60hz_"
global.packname = "ig : FanCwoHyper"
global.author = "ᥴі𝗍rᥲᥲᶠᵃⁿⁿ💞\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.tekspushkon = ''
global.keyopenai ='iigf'

global.limitawal = {
    premium: "Infinity",
    free: 5
}

//media target
global.thumb = { url: 'https://img5.pixhost.to/images/2969/568633095_jetzdev.jpg' }//ur thumb pic
global.defaultpp = 'https://img5.pixhost.to/images/2969/568633095_jetzdev.jpg' //default pp wa

//messages
global.mess = {
    selesai: 'ᑲᥱrһᥲsіᥣ kᥲk💞', 
    owner: 'kһᥙsᥙs ᥆ᥕᥒᥱr kᥙ ᥡᥲ kᥲk💝',
    private: 'kһᥙsᥙs ძі ⍴rі᥎ᥲ𝗍 ᥴһᥲ𝗍 kᥲk🍜',
    group: 'kһᥙsᥙs ძі ძᥲᥣᥲm gr᥆ᥙ⍴ ᥡᥲ kᥲk😁',
    wait: 'sᥱᑲᥱᥒ𝗍ᥲr kᥲk ᥲᑲᥲᥒg 𝖿ᥲᥒ ᥣᥲgі mᥲm mіᥱ🍜',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
