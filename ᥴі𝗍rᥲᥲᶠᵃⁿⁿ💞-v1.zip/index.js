function _0x31bb() {
  const _0x797db6 = ['green', '\x0aitem1.X-ABLabel:Click\x20here\x20to\x20chat\x0aitem2.EMAIL;type=INTERNET:', 'readline', '\x0aFN:', 'packname', 'query', 'sessionName', '\x0aitem1.TEL;waid=', 'Error\x20in\x20Connection.update\x20', 'Bad\x20Session\x20File,\x20Please\x20Delete\x20Session\x20and\x20Scan\x20Again', 'BEGIN:VCARD\x0aVERSION:3.0\x0aN:', './lib/color', 'user', 'mime', 'cyan', 'WhatsApp', 'colors', 'split', 'error', 'status@broadcast', 'endsWith', './lib/spinner', 'sticker', 'connectionReplaced', './index.js', 'setStatus', 'keys', 'downloadMediaMessage', 'promises', 'fromMe', 'conversation', 'Connection\x20Replaced,\x20Another\x20New\x20Session\x20Opened,\x20Please\x20Close\x20Current\x20Session\x20First', 'timedOut', '\x0a\x0a\x0aSilahkan\x20masukin\x20nomor\x20Whatsapp\x20Awali\x20dengan\x2062:\x0a', '100000', 'audio/ogg;\x20codecs=opus', 'stdout', '63NcLpna', 'categories', 'messages.upsert', 'readFileSync', 'asDocument', 'document', 'video/mp4', 'ephemeralMessage', 'msg', './case', '\x20CREDIT:\x20AnanOfficiaL\x0a', 'replace', 'readMessages', 'requestPairingCode', 'sendButImg', 'bold', 'viewOnceMessage', '@s.whatsapp.net', '10699aiQGlj', 'key', 'headers', 'subject', 'question', 'sendContact', '[\x20Always\x20Anan\x20]', 'push', 'connectionClosed', '11QpcleP', 'matchAll', 'content-type', 'withoutContact', 'application/pdf', 'BAE5', '7778530CtGWNs', 'store', 'creds.update', 'sendMedia', '\x0a\x0aWaiting\x20for\x20New\x20Messages..', 'fromObject', '5920kscPoo', 'appenTextMessage', 'type', 'messages.update', ';;;;\x0aitem4.X-ABLabel:Region\x0aEND:VCARD', 'relayMessage', 'connecting', 'Chrome\x20(Linux)', '166352CVzhcy', 'audio/mpeg', '../case.js', 'magenta', 'test', 'yellow', 'send5ButLoc', 'end', 'blue', 'size', './module', 'contacts', 'image/webp', 'getName', 'statSync', 'server', 'getNumber', 'public', 'writeFileSync', './case.js', 'loggedOut', 'asLocation', 'createInterface', 'gif', 'ignore', 'parseMention', 'map', 'sendFile', './lib/exif', 'toString', './lib', 'pollUpdates', 'authState', 'startsWith', 'Device\x20Logged\x20Out,\x20Please\x20Scan\x20Again\x20And\x20Run.', 'existsSync', 'close', '744bUHkFV', 'Updated', 'sendMessage', 'log', '.bin', '@whiskeysockets/baileys', '\x20TELEGRAM:\x20AlwaysAnan\x20', 'registered', '\x20Contact', 'asImage', 'application/octet-stream', 'international', 'decodeJid', 'video', 'unlink', '\x0aitem3.X-ABLabel:GitHub\x0aitem4.ADR:;;', '3601143etfwbS', 'true', '664896OZQJIC', 'name', 'downloadAndSaveMediaMessage', 'isBuffer', 'mtype', 'restartRequired', 'string', '../index.js', 'notify', 'contextInfo', 'pop', 'child', 'ext', 'imageMessage', 'message', 'open', 'remoteJid', 'moment-timezone', 'length', 'fromBuffer', 'json', '8cwMQGl', 'data', '\x20YT\x20CHANNEL:\x20@alwaysanan', '\x0a🥊Connecting...', 'connection', 'from', 'gold', 'sendFileUrl', './lib/loader', 'author', 'sendTextWithMentions', 'connection.update', 'sendVideoAsSticker', 'getFile', '870FHEHtK', 'viewOnce', 'audio', 'status', 'sendText', 'receivedPendingNotifications', '1QZjieC', 'filename', 'sendKatalog', 'sendButtonText', 'sendImage', 'image', 'concat', 'white', 'connectionLost', 'asVideo', 'Connection\x20Lost\x20from\x20Server,\x20reconnecting...', 'trim', 'serializeM', 'Cheems\x20Bot\x20Here', 'mimetype', 'utf-8', 'parse', 'creds', 'base64', '650186HrDIIL', 'Message', 'alloc', 'asSticker', 'silent', 'verifiedName'];
  _0x31bb = function () {
    return _0x797db6;
  };
  return _0x31bb();
}
const _0x1a6f9d = _0x4abd;
(function (_0x5a3047, _0x513494) {
  const _0x3080ad = _0x4abd;
  const _0x2dddfe = _0x5a3047();
  while (!![]) {
    try {
      const _0x2ad658 = parseInt(_0x3080ad(0xbc)) / 0x1 * (parseInt(_0x3080ad(0xcf)) / 0x2) + -parseInt(_0x3080ad(0x93)) / 0x3 * (parseInt(_0x3080ad(0xa8)) / 0x4) + -parseInt(_0x3080ad(0x121)) / 0x5 * (-parseInt(_0x3080ad(0xb6)) / 0x6) + -parseInt(_0x3080ad(0x91)) / 0x7 + parseInt(_0x3080ad(0x129)) / 0x8 * (parseInt(_0x3080ad(0xfa)) / 0x9) + -parseInt(_0x3080ad(0x11b)) / 0xa * (-parseInt(_0x3080ad(0x115)) / 0xb) + -parseInt(_0x3080ad(0x81)) / 0xc * (parseInt(_0x3080ad(0x10c)) / 0xd);
      if (_0x2ad658 === _0x513494) {
        break;
      } else {
        _0x2dddfe['push'](_0x2dddfe['shift']());
      }
    } catch (_0x5165e4) {
      _0x2dddfe['push'](_0x2dddfe['shift']());
    }
  }
})(_0x31bb, 0x64735);
const {
  modul
} = require(_0x1a6f9d(0x133));
const moment = require(_0x1a6f9d(0xa4));
const {
  baileys,
  boom,
  chalk,
  fs,
  figlet,
  FileType,
  path,
  pino,
  process,
  PhoneNumber,
  axios,
  yargs,
  _
} = modul;
const {
  Boom
} = boom;
const {
  default: makeWASocket,
  BufferJSON,
  initInMemoryKeyStore,
  DisconnectReason,
  AnyMessageContent,
  makeInMemoryStore,
  useMultiFileAuthState,
  delay,
  fetchLatestBaileysVersion,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  generateMessageID,
  downloadContentFromMessage,
  jidDecode,
  getAggregateVotesInPollMessage,
  proto
} = require(_0x1a6f9d(0x86));
const readline = require(_0x1a6f9d(0xd7));
const {
  color,
  bgcolor
} = require(_0x1a6f9d(0xe0));
const colors = require(_0x1a6f9d(0xe5));
const {
  start
} = require(_0x1a6f9d(0xea));
const {
  uncache,
  nocache
} = require(_0x1a6f9d(0xb0));
const {
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid
} = require(_0x1a6f9d(0x78));
const {
  smsg,
  isUrl,
  generateMessageTag,
  getBuffer,
  getSizeMedia,
  fetchJson,
  await,
  sleep,
  reSize
} = require('./lib/myfunc');
const prefix = '';
const question = _0x264571 => {
  const _0x193339 = _0x1a6f9d;
  const _0x26fecd = readline[_0x193339(0x72)]({
    'input': process['stdin'],
    'output': process[_0x193339(0xf9)]
  });
  return new Promise(_0x5cfa7d => {
    const _0x21dea1 = _0x193339;
    _0x26fecd[_0x21dea1(0x110)](_0x264571, _0x5cfa7d);
  });
};
const store = makeInMemoryStore({
  'logger': pino()[_0x1a6f9d(0x9e)]({
    'level': _0x1a6f9d(0xd3),
    'stream': _0x1a6f9d(0x11c)
  })
});
const pairingCode = !![];
require(_0x1a6f9d(0x6f));
nocache(_0x1a6f9d(0x12b), _0x240341 => console[_0x1a6f9d(0x84)](color('[\x20CHANGE\x20]', _0x1a6f9d(0xd5)), color('\x27' + _0x240341 + '\x27', _0x1a6f9d(0xd5)), _0x1a6f9d(0x82)));
require(_0x1a6f9d(0xed));
nocache(_0x1a6f9d(0x9a), _0xbf911e => console[_0x1a6f9d(0x84)](color('[\x20CHANGE\x20]', _0x1a6f9d(0xd5)), color('\x27' + _0xbf911e + '\x27', 'green'), _0x1a6f9d(0x82)));
async function NawBotz() {
  const _0x5c1b54 = _0x1a6f9d;
  const {
    state: _0x2fe127,
    saveCreds: _0xbef84f
  } = await useMultiFileAuthState(global[_0x5c1b54(0xdb)]);
  const _0x2f6a6f = makeWASocket({
    'logger': pino({
      'level': _0x5c1b54(0xd3)
    }),
    'printQRInTerminal': !pairingCode,
    'auth': _0x2fe127,
    'browser': [_0x5c1b54(0x128), '', '']
  });
  if (pairingCode && !_0x2f6a6f[_0x5c1b54(0x7c)][_0x5c1b54(0xcd)][_0x5c1b54(0x88)]) {
    const _0x20de4a = await question(color(_0x5c1b54(0xf6), _0x5c1b54(0x12c)));
    const _0x5009dc = await _0x2f6a6f[_0x5c1b54(0x107)](_0x20de4a[_0x5c1b54(0xc7)]());
    console['log'](color('⚠︎\x20Kode\x20Pairing\x20Bot\x20Whatsapp\x20kamu\x20:', _0x5c1b54(0xae)), color('' + _0x5009dc, _0x5c1b54(0xc3)));
  }
  store['bind'](_0x2f6a6f['ev']);
  _0x2f6a6f['ev']['on'](_0x5c1b54(0xb3), async _0x34aeaa => {
    const _0x5391c7 = _0x5c1b54;
    const {
      connection: _0x586cad,
      lastDisconnect: _0xe747c2
    } = _0x34aeaa;
    try {
      if (_0x586cad === _0x5391c7(0x80)) {
        let _0xbaf66d = new Boom(_0xe747c2?.[_0x5391c7(0xe7)])?.['output']['statusCode'];
        if (_0xbaf66d === DisconnectReason['badSession']) {
          console[_0x5391c7(0x84)](_0x5391c7(0xde));
          NawBotz();
        } else {
          if (_0xbaf66d === DisconnectReason[_0x5391c7(0x114)]) {
            console[_0x5391c7(0x84)]('Connection\x20closed,\x20reconnecting....');
            NawBotz();
          } else {
            if (_0xbaf66d === DisconnectReason[_0x5391c7(0xc4)]) {
              console[_0x5391c7(0x84)](_0x5391c7(0xc6));
              NawBotz();
            } else {
              if (_0xbaf66d === DisconnectReason[_0x5391c7(0xec)]) {
                console['log'](_0x5391c7(0xf4));
                NawBotz();
              } else {
                if (_0xbaf66d === DisconnectReason[_0x5391c7(0x70)]) {
                  console[_0x5391c7(0x84)](_0x5391c7(0x7e));
                  NawBotz();
                } else {
                  if (_0xbaf66d === DisconnectReason[_0x5391c7(0x98)]) {
                    console[_0x5391c7(0x84)]('Restart\x20Required,\x20Restarting...');
                    NawBotz();
                  } else {
                    if (_0xbaf66d === DisconnectReason[_0x5391c7(0xf5)]) {
                      console[_0x5391c7(0x84)]('Connection\x20TimedOut,\x20Reconnecting...');
                      NawBotz();
                    } else {
                      _0x2f6a6f[_0x5391c7(0x130)]('Unknown\x20DisconnectReason:\x20' + _0xbaf66d + '|' + _0x586cad);
                    }
                  }
                }
              }
            }
          }
        }
      }
      (_0x34aeaa[_0x5391c7(0xac)] == _0x5391c7(0x127) || _0x34aeaa[_0x5391c7(0xbb)] == 'false') && console[_0x5391c7(0x84)](color(_0x5391c7(0xab), _0x5391c7(0x12e)));
      (_0x34aeaa[_0x5391c7(0xac)] == _0x5391c7(0xa2) || _0x34aeaa['receivedPendingNotifications'] == _0x5391c7(0x92)) && (console[_0x5391c7(0x84)](color('\x20', _0x5391c7(0x12c))), console[_0x5391c7(0x84)](color('🌿Connected\x20to\x20=>\x20' + JSON['stringify'](_0x2f6a6f[_0x5391c7(0xe1)], null, 0x2), _0x5391c7(0x12e))), await delay(0x7cf), console[_0x5391c7(0x84)](chalk[_0x5391c7(0x12e)]('\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20' + chalk[_0x5391c7(0x109)][_0x5391c7(0x131)](_0x5391c7(0x112)) + '\x0a\x0a')), console[_0x5391c7(0x84)](color('<\x20==================================================\x20>', _0x5391c7(0xe3))), console['log'](color('\x0a' + themeemoji + _0x5391c7(0xaa), _0x5391c7(0x12c))), console[_0x5391c7(0x84)](color(themeemoji + _0x5391c7(0x87), _0x5391c7(0x12c))), console['log'](color(themeemoji + '\x20WA\x20NUMBER:\x2062895428251533', 'magenta')), console[_0x5391c7(0x84)](color(themeemoji + _0x5391c7(0x104), _0x5391c7(0x12c))));
    } catch (_0x1233ea) {
      console[_0x5391c7(0x84)](_0x5391c7(0xdd) + _0x1233ea);
      NawBotz();
    }
  });
  await delay(0x15b3);
  start('2', colors[_0x5c1b54(0x109)][_0x5c1b54(0xc3)](_0x5c1b54(0x11f)));
  _0x2f6a6f['ev']['on'](_0x5c1b54(0x11d), await _0xbef84f);
  _0x2f6a6f['ev']['on'](_0x5c1b54(0xfc), async _0x46f8ba => {
    const _0x5f46b6 = _0x5c1b54;
    try {
      const _0x533099 = _0x46f8ba['messages'][0x0];
      if (!_0x533099[_0x5f46b6(0xa1)]) {
        return;
      }
      _0x533099[_0x5f46b6(0xa1)] = Object[_0x5f46b6(0xef)](_0x533099[_0x5f46b6(0xa1)])[0x0] === _0x5f46b6(0x101) ? _0x533099['message'][_0x5f46b6(0x101)][_0x5f46b6(0xa1)] : _0x533099[_0x5f46b6(0xa1)];
      _0x533099[_0x5f46b6(0x10d)] && _0x533099['key'][_0x5f46b6(0xa3)] === _0x5f46b6(0xe8) && (await _0x2f6a6f[_0x5f46b6(0x106)]([_0x533099[_0x5f46b6(0x10d)]]));
      if (!_0x2f6a6f[_0x5f46b6(0x13a)] && !_0x533099['key'][_0x5f46b6(0xf2)] && _0x46f8ba[_0x5f46b6(0x123)] === _0x5f46b6(0x9b)) {
        return;
      }
      if (_0x533099[_0x5f46b6(0x10d)]['id'][_0x5f46b6(0x7d)](_0x5f46b6(0x11a)) && _0x533099['key']['id']['length'] === 0x10) {
        return;
      }
      const _0x206a8a = smsg(_0x2f6a6f, _0x533099, store);
      require(_0x5f46b6(0x103))(_0x2f6a6f, _0x206a8a, _0x46f8ba, store);
    } catch (_0x425db8) {
      console['log'](_0x425db8);
    }
  });
  async function _0x1e69ce(_0x255064) {
    const _0x3d43e0 = _0x5c1b54;
    if (store) {
      const _0x3f5398 = await store['loadMessage'](_0x255064[_0x3d43e0(0xa3)], _0x255064['id']);
      return _0x3f5398?.[_0x3d43e0(0xa1)];
    }
    return {
      'conversation': _0x3d43e0(0xc9)
    };
  }
  _0x2f6a6f['ev']['on'](_0x5c1b54(0x124), async _0x5300ab => {
    const _0xb022d4 = _0x5c1b54;
    for (const {
      key: _0x7fa4e5,
      update: _0x1a3725
    } of _0x5300ab) {
      if (_0x1a3725[_0xb022d4(0x7b)] && _0x7fa4e5[_0xb022d4(0xf2)]) {
        const _0x44f12a = await _0x1e69ce(_0x7fa4e5);
        if (_0x44f12a) {
          const _0x46da61 = await getAggregateVotesInPollMessage({
            'message': _0x44f12a,
            'pollUpdates': _0x1a3725[_0xb022d4(0x7b)]
          });
          var _0x46c8ff = _0x46da61['filter'](_0x1fd04b => _0x1fd04b['voters'][_0xb022d4(0xa5)] !== 0x0)[0x0]?.['name'];
          if (_0x46c8ff == undefined) {
            return;
          }
          var _0x9c451b = prefix + _0x46c8ff;
          _0x2f6a6f[_0xb022d4(0x122)](_0x9c451b, _0x5300ab);
        }
      }
    }
  });
  _0x2f6a6f[_0x5c1b54(0xb2)] = async (_0x140c95, _0x5de12b, _0x107ae8, _0x422e42 = {}) => _0x2f6a6f[_0x5c1b54(0x83)](_0x140c95, {
    'text': _0x5de12b,
    'contextInfo': {
      'mentionedJid': [..._0x5de12b[_0x5c1b54(0x116)](/@(\d{0,16})/g)][_0x5c1b54(0x76)](_0x11f4d9 => _0x11f4d9[0x1] + '@s.whatsapp.net')
    },
    ..._0x422e42
  }, {
    'quoted': _0x107ae8
  });
  _0x2f6a6f['decodeJid'] = _0x36a463 => {
    const _0x145509 = _0x5c1b54;
    if (!_0x36a463) {
      return _0x36a463;
    }
    if (/:\d+@/gi[_0x145509(0x12d)](_0x36a463)) {
      let _0x346bda = jidDecode(_0x36a463) || {};
      return _0x346bda[_0x145509(0xe1)] && _0x346bda[_0x145509(0x138)] && _0x346bda[_0x145509(0xe1)] + '@' + _0x346bda[_0x145509(0x138)] || _0x36a463;
    } else {
      return _0x36a463;
    }
  };
  _0x2f6a6f['ev']['on']('contacts.update', _0x114f32 => {
    const _0x2cf71e = _0x5c1b54;
    for (let _0x32ada3 of _0x114f32) {
      let _0x21425c = _0x2f6a6f[_0x2cf71e(0x8d)](_0x32ada3['id']);
      if (store && store[_0x2cf71e(0x134)]) {
        store['contacts'][_0x21425c] = {
          'id': _0x21425c,
          'name': _0x32ada3[_0x2cf71e(0x9b)]
        };
      }
    }
  });
  _0x2f6a6f[_0x5c1b54(0x136)] = (_0x453d5d, _0x394085 = ![]) => {
    const _0x361259 = _0x5c1b54;
    id = _0x2f6a6f['decodeJid'](_0x453d5d);
    _0x394085 = _0x2f6a6f[_0x361259(0x118)] || _0x394085;
    let _0x439007;
    if (id[_0x361259(0xe9)]('@g.us')) {
      return new Promise(async _0x3c15b6 => {
        const _0x3a4435 = _0x361259;
        _0x439007 = store[_0x3a4435(0x134)][id] || {};
        if (!(_0x439007[_0x3a4435(0x94)] || _0x439007[_0x3a4435(0x10f)])) {
          _0x439007 = _0x2f6a6f['groupMetadata'](id) || {};
        }
        _0x3c15b6(_0x439007['name'] || _0x439007['subject'] || PhoneNumber('+' + id[_0x3a4435(0x105)](_0x3a4435(0x10b), ''))[_0x3a4435(0x139)](_0x3a4435(0x8c)));
      });
    } else {
      _0x439007 = id === '0@s.whatsapp.net' ? {
        'id': id,
        'name': _0x361259(0xe4)
      } : id === _0x2f6a6f[_0x361259(0x8d)](_0x2f6a6f[_0x361259(0xe1)]['id']) ? _0x2f6a6f[_0x361259(0xe1)] : store[_0x361259(0x134)][id] || {};
    }
    return (_0x394085 ? '' : _0x439007[_0x361259(0x94)]) || _0x439007[_0x361259(0x10f)] || _0x439007[_0x361259(0xd4)] || PhoneNumber('+' + _0x453d5d[_0x361259(0x105)](_0x361259(0x10b), ''))[_0x361259(0x139)](_0x361259(0x8c));
  };
  _0x2f6a6f[_0x5c1b54(0x75)] = (_0x2118b1 = '') => {
    const _0x17ff25 = _0x5c1b54;
    return [..._0x2118b1[_0x17ff25(0x116)](/@([0-9]{5,16}|0)/g)][_0x17ff25(0x76)](_0xb6513a => _0xb6513a[0x1] + _0x17ff25(0x10b));
  };
  _0x2f6a6f[_0x5c1b54(0x111)] = async (_0x29d2e2, _0x17c885, _0x33fadd = '', _0x12be9b = {}) => {
    const _0xa97d51 = _0x5c1b54;
    let _0x4574a6 = [];
    for (let _0x4a6a17 of _0x17c885) {
      _0x4574a6[_0xa97d51(0x113)]({
        'displayName': await _0x2f6a6f[_0xa97d51(0x136)](_0x4a6a17),
        'vcard': _0xa97d51(0xdf) + (await _0x2f6a6f[_0xa97d51(0x136)](_0x4a6a17)) + _0xa97d51(0xd8) + (await _0x2f6a6f[_0xa97d51(0x136)](_0x4a6a17)) + _0xa97d51(0xdc) + _0x4a6a17 + ':' + _0x4a6a17 + _0xa97d51(0xd6) + ytname + '\x0aitem2.X-ABLabel:YouTube\x0aitem3.URL:' + socialm + _0xa97d51(0x90) + location + _0xa97d51(0x125)
      });
    }
    _0x2f6a6f[_0xa97d51(0x83)](_0x29d2e2, {
      'contacts': {
        'displayName': _0x4574a6[_0xa97d51(0xa5)] + _0xa97d51(0x89),
        'contacts': _0x4574a6
      },
      ..._0x12be9b
    }, {
      'quoted': _0x33fadd
    });
  };
  _0x2f6a6f[_0x5c1b54(0xee)] = _0x37deb7 => {
    const _0x1ecfc9 = _0x5c1b54;
    _0x2f6a6f[_0x1ecfc9(0xda)]({
      'tag': 'iq',
      'attrs': {
        'to': _0x1ecfc9(0x10b),
        'type': 'set',
        'xmlns': _0x1ecfc9(0xb9)
      },
      'content': [{
        'tag': _0x1ecfc9(0xb9),
        'attrs': {},
        'content': Buffer[_0x1ecfc9(0xad)](_0x37deb7, _0x1ecfc9(0xcb))
      }]
    });
    return _0x37deb7;
  };
  _0x2f6a6f[_0x5c1b54(0x13a)] = !![];
  _0x2f6a6f[_0x5c1b54(0xc0)] = async (_0x3064e5, _0x3cad7f, _0x4b7285 = '', _0x1f594d = '', _0x2976bc) => {
    const _0x5d81a0 = _0x5c1b54;
    let _0x595b0f = Buffer[_0x5d81a0(0x96)](_0x3cad7f) ? _0x3cad7f : /^data:.*?\/.*?;base64,/i[_0x5d81a0(0x12d)](_0x3cad7f) ? Buffer[_0x5d81a0(0xad)](_0x3cad7f['split']`,`[0x1], _0x5d81a0(0xce)) : /^https?:\/\//[_0x5d81a0(0x12d)](_0x3cad7f) ? await await getBuffer(_0x3cad7f) : fs[_0x5d81a0(0x7f)](_0x3cad7f) ? fs[_0x5d81a0(0xfd)](_0x3cad7f) : Buffer[_0x5d81a0(0xd1)](0x0);
    return await _0x2f6a6f[_0x5d81a0(0x83)](_0x3064e5, {
      'image': _0x595b0f,
      'caption': _0x4b7285,
      ..._0x2976bc
    }, {
      'quoted': _0x1f594d
    });
  };
  _0x2f6a6f['sendImageAsSticker'] = async (_0x56ca8d, _0x560216, _0x239fb9, _0x1c72c2 = {}) => {
    const _0x33ed36 = _0x5c1b54;
    let _0x39701c = Buffer[_0x33ed36(0x96)](_0x560216) ? _0x560216 : /^data:.*?\/.*?;base64,/i[_0x33ed36(0x12d)](_0x560216) ? Buffer[_0x33ed36(0xad)](_0x560216[_0x33ed36(0xe6)]`,`[0x1], 'base64') : /^https?:\/\//['test'](_0x560216) ? await await getBuffer(_0x560216) : fs[_0x33ed36(0x7f)](_0x560216) ? fs['readFileSync'](_0x560216) : Buffer[_0x33ed36(0xd1)](0x0);
    let _0x14573f;
    _0x1c72c2 && (_0x1c72c2['packname'] || _0x1c72c2[_0x33ed36(0xb1)]) ? _0x14573f = await writeExifImg(_0x39701c, _0x1c72c2) : _0x14573f = await imageToWebp(_0x39701c);
    await _0x2f6a6f[_0x33ed36(0x83)](_0x56ca8d, {
      'sticker': {
        'url': _0x14573f
      },
      ..._0x1c72c2
    }, {
      'quoted': _0x239fb9
    })['then'](_0x3f685c => {
      fs['unlinkSync'](_0x14573f);
      return _0x3f685c;
    });
  };
  _0x2f6a6f[_0x5c1b54(0xb4)] = async (_0x151f28, _0x16e90f, _0x9b3079, _0x34fbd0 = {}) => {
    const _0x50331e = _0x5c1b54;
    let _0x1c8de9 = Buffer[_0x50331e(0x96)](_0x16e90f) ? _0x16e90f : /^data:.*?\/.*?;base64,/i['test'](_0x16e90f) ? Buffer['from'](_0x16e90f[_0x50331e(0xe6)]`,`[0x1], 'base64') : /^https?:\/\//[_0x50331e(0x12d)](_0x16e90f) ? await await getBuffer(_0x16e90f) : fs[_0x50331e(0x7f)](_0x16e90f) ? fs[_0x50331e(0xfd)](_0x16e90f) : Buffer[_0x50331e(0xd1)](0x0);
    let _0x27abed;
    _0x34fbd0 && (_0x34fbd0[_0x50331e(0xd9)] || _0x34fbd0[_0x50331e(0xb1)]) ? _0x27abed = await writeExifVid(_0x1c8de9, _0x34fbd0) : _0x27abed = await videoToWebp(_0x1c8de9);
    await _0x2f6a6f[_0x50331e(0x83)](_0x151f28, {
      'sticker': {
        'url': _0x27abed
      },
      ..._0x34fbd0
    }, {
      'quoted': _0x9b3079
    });
    return _0x27abed;
  };
  _0x2f6a6f['copyNForward'] = async (_0x36379f, _0x466b04, _0x2df35d = ![], _0x308799 = {}) => {
    const _0x4dd059 = _0x5c1b54;
    let _0x5dfd59;
    _0x308799['readViewOnce'] && (_0x466b04[_0x4dd059(0xa1)] = _0x466b04['message'] && _0x466b04['message'][_0x4dd059(0x101)] && _0x466b04['message'][_0x4dd059(0x101)]['message'] ? _0x466b04[_0x4dd059(0xa1)]['ephemeralMessage'][_0x4dd059(0xa1)] : _0x466b04[_0x4dd059(0xa1)] || undefined, _0x5dfd59 = Object[_0x4dd059(0xef)](_0x466b04[_0x4dd059(0xa1)][_0x4dd059(0x10a)][_0x4dd059(0xa1)])[0x0], delete (_0x466b04[_0x4dd059(0xa1)] && _0x466b04[_0x4dd059(0xa1)][_0x4dd059(0x74)] ? _0x466b04[_0x4dd059(0xa1)][_0x4dd059(0x74)] : _0x466b04[_0x4dd059(0xa1)] || undefined), delete _0x466b04[_0x4dd059(0xa1)]['viewOnceMessage']['message'][_0x5dfd59][_0x4dd059(0xb7)], _0x466b04[_0x4dd059(0xa1)] = {
      ..._0x466b04['message'][_0x4dd059(0x10a)][_0x4dd059(0xa1)]
    });
    let _0x2d5437 = Object[_0x4dd059(0xef)](_0x466b04[_0x4dd059(0xa1)])[0x0];
    let _0x106509 = await generateForwardMessageContent(_0x466b04, _0x2df35d);
    let _0x256aed = Object[_0x4dd059(0xef)](_0x106509)[0x0];
    let _0x32415d = {};
    if (_0x2d5437 != _0x4dd059(0xf3)) {
      _0x32415d = _0x466b04['message'][_0x2d5437][_0x4dd059(0x9c)];
    }
    _0x106509[_0x256aed][_0x4dd059(0x9c)] = {
      ..._0x32415d,
      ..._0x106509[_0x256aed][_0x4dd059(0x9c)]
    };
    const _0x36c614 = await generateWAMessageFromContent(_0x36379f, _0x106509, _0x308799 ? {
      ..._0x106509[_0x256aed],
      ..._0x308799,
      ...(_0x308799[_0x4dd059(0x9c)] ? {
        'contextInfo': {
          ..._0x106509[_0x256aed]['contextInfo'],
          ..._0x308799['contextInfo']
        }
      } : {})
    } : {});
    await _0x2f6a6f[_0x4dd059(0x126)](_0x36379f, _0x36c614[_0x4dd059(0xa1)], {
      'messageId': _0x36c614[_0x4dd059(0x10d)]['id']
    });
    return _0x36c614;
  };
  _0x2f6a6f[_0x5c1b54(0x95)] = async (_0x19543d, _0x319c8d, _0x42f9ea = !![]) => {
    const _0x254074 = _0x5c1b54;
    let _0x5835bb = _0x19543d[_0x254074(0x102)] ? _0x19543d[_0x254074(0x102)] : _0x19543d;
    let _0x4c13d1 = (_0x19543d[_0x254074(0x102)] || _0x19543d)[_0x254074(0xca)] || '';
    let _0x490442 = _0x19543d['mtype'] ? _0x19543d[_0x254074(0x97)]['replace'](/Message/gi, '') : _0x4c13d1[_0x254074(0xe6)]('/')[0x0];
    const _0x1b31ee = await downloadContentFromMessage(_0x5835bb, _0x490442);
    let _0x369520 = Buffer['from']([]);
    for await (const _0x3b8a3e of _0x1b31ee) {
      _0x369520 = Buffer[_0x254074(0xc2)]([_0x369520, _0x3b8a3e]);
    }
    let _0x33a902 = await FileType[_0x254074(0xa6)](_0x369520);
    trueFileName = _0x42f9ea ? _0x319c8d + '.' + _0x33a902[_0x254074(0x9f)] : _0x319c8d;
    await fs[_0x254074(0x6e)](trueFileName, _0x369520);
    return trueFileName;
  };
  _0x2f6a6f[_0x5c1b54(0xf0)] = async _0x431f2a => {
    const _0x5507bf = _0x5c1b54;
    let _0x129e2b = (_0x431f2a['msg'] || _0x431f2a)[_0x5507bf(0xca)] || '';
    let _0x5ccb32 = _0x431f2a[_0x5507bf(0x97)] ? _0x431f2a[_0x5507bf(0x97)][_0x5507bf(0x105)](/Message/gi, '') : _0x129e2b[_0x5507bf(0xe6)]('/')[0x0];
    const _0x5bb8fd = await downloadContentFromMessage(_0x431f2a, _0x5ccb32);
    let _0x38a786 = Buffer['from']([]);
    for await (const _0x15ac27 of _0x5bb8fd) {
      _0x38a786 = Buffer[_0x5507bf(0xc2)]([_0x38a786, _0x15ac27]);
    }
    return _0x38a786;
  };
  _0x2f6a6f['getFile'] = async (_0xc540d4, _0x5d4c23) => {
    const _0x802f7d = _0x5c1b54;
    let _0x720918;
    let _0x4da941 = Buffer[_0x802f7d(0x96)](_0xc540d4) ? _0xc540d4 : /^data:.*?\/.*?;base64,/i[_0x802f7d(0x12d)](_0xc540d4) ? Buffer[_0x802f7d(0xad)](_0xc540d4[_0x802f7d(0xe6)]`,`[0x1], 'base64') : /^https?:\/\//[_0x802f7d(0x12d)](_0xc540d4) ? await (_0x720918 = await getBuffer(_0xc540d4)) : fs[_0x802f7d(0x7f)](_0xc540d4) ? (filename = _0xc540d4, fs['readFileSync'](_0xc540d4)) : typeof _0xc540d4 === _0x802f7d(0x99) ? _0xc540d4 : Buffer[_0x802f7d(0xd1)](0x0);
    let _0x4402cd = (await FileType[_0x802f7d(0xa6)](_0x4da941)) || {
      'mime': _0x802f7d(0x8b),
      'ext': _0x802f7d(0x85)
    };
    filename = path['join'](__filename, _0x802f7d(0x7a) + new Date() * 0x1 + '.' + _0x4402cd[_0x802f7d(0x9f)]);
    if (_0x4da941 && _0x5d4c23) {
      fs[_0x802f7d(0xf1)]['writeFile'](filename, _0x4da941);
    }
    return {
      'res': _0x720918,
      'filename': filename,
      'size': await getSizeMedia(_0x4da941),
      ..._0x4402cd,
      'data': _0x4da941
    };
  };
  _0x2f6a6f[_0x5c1b54(0x11e)] = async (_0x2d66b8, _0x46f9d8, _0x56db8d = '', _0x5aaca5 = '', _0x233200 = '', _0x1bb973 = {}) => {
    const _0x456c68 = _0x5c1b54;
    let _0x3ac8d8 = await _0x2f6a6f[_0x456c68(0xb5)](_0x46f9d8, !![]);
    let {
      mime: _0x266093,
      ext: _0x12bfe1,
      res: _0x3de94c,
      data: _0x2c7602,
      filename: _0x1a0ddd
    } = _0x3ac8d8;
    if (_0x3de94c && _0x3de94c[_0x456c68(0xb9)] !== 0xc8 || file['length'] <= 0x10000) {
      try {
        throw {
          'json': JSON[_0x456c68(0xcc)](file[_0x456c68(0x79)]())
        };
      } catch (_0x4b2abb) {
        if (_0x4b2abb[_0x456c68(0xa7)]) {
          throw _0x4b2abb['json'];
        }
      }
    }
    let _0x20e48e = '';
    let _0x1bbdc2 = _0x266093;
    let _0x73443f = _0x1a0ddd;
    if (_0x1bb973[_0x456c68(0xfe)]) {
      _0x20e48e = _0x456c68(0xff);
    }
    if (_0x1bb973['asSticker'] || /webp/[_0x456c68(0x12d)](_0x266093)) {
      let {
        writeExif: _0x559b65
      } = require(_0x456c68(0x78));
      let _0x5eeda9 = {
        'mimetype': _0x266093,
        'data': _0x2c7602
      };
      _0x73443f = await _0x559b65(_0x5eeda9, {
        'packname': _0x1bb973['packname'] ? _0x1bb973['packname'] : global[_0x456c68(0xd9)],
        'author': _0x1bb973[_0x456c68(0xb1)] ? _0x1bb973[_0x456c68(0xb1)] : global['author'],
        'categories': _0x1bb973[_0x456c68(0xfb)] ? _0x1bb973[_0x456c68(0xfb)] : []
      });
      await fs['promises'][_0x456c68(0x8f)](_0x1a0ddd);
      _0x20e48e = 'sticker';
      _0x1bbdc2 = _0x456c68(0x135);
    } else {
      if (/image/[_0x456c68(0x12d)](_0x266093)) {
        _0x20e48e = _0x456c68(0xc1);
      } else {
        if (/video/[_0x456c68(0x12d)](_0x266093)) {
          _0x20e48e = _0x456c68(0x8e);
        } else {
          if (/audio/[_0x456c68(0x12d)](_0x266093)) {
            _0x20e48e = _0x456c68(0xb8);
          } else {
            _0x20e48e = _0x456c68(0xff);
          }
        }
      }
    }
    await _0x2f6a6f[_0x456c68(0x83)](_0x2d66b8, {
      [_0x20e48e]: {
        'url': _0x73443f
      },
      'caption': _0x5aaca5,
      'mimetype': _0x1bbdc2,
      'fileName': _0x56db8d,
      ..._0x1bb973
    }, {
      'quoted': _0x233200,
      ..._0x1bb973
    });
    return fs[_0x456c68(0xf1)][_0x456c68(0x8f)](_0x73443f);
  };
  _0x2f6a6f[_0x5c1b54(0xba)] = (_0x4bcae1, _0x493169, _0x56fa62 = '', _0x4e3966) => _0x2f6a6f[_0x5c1b54(0x83)](_0x4bcae1, {
    'text': _0x493169,
    ..._0x4e3966
  }, {
    'quoted': _0x56fa62
  });
  _0x2f6a6f[_0x5c1b54(0xc8)] = _0x57e43c => smsg(_0x2f6a6f, _0x57e43c, store);
  _0x2f6a6f[_0x5c1b54(0xbf)] = (_0x33bc79, _0x16d4b1 = [], _0x5995c6, _0x44fd6b, _0x2c89ee = '', _0x5f1831 = {}) => {
    const _0x1024d1 = _0x5c1b54;
    let _0x37bca4 = {
      'text': _0x5995c6,
      'footer': _0x44fd6b,
      'buttons': _0x16d4b1,
      'headerType': 0x2,
      ..._0x5f1831
    };
    _0x2f6a6f[_0x1024d1(0x83)](_0x33bc79, _0x37bca4, {
      'quoted': _0x2c89ee,
      ..._0x5f1831
    });
  };
  _0x2f6a6f[_0x5c1b54(0xbe)] = async (_0x1c8a92, _0x4bb46b = '', _0x1d59f9 = '', _0x359ccd, _0x495821 = {}) => {
    const _0x38c97b = _0x5c1b54;
    let _0x1c1ce5 = await prepareWAMessageMedia({
      'image': _0x359ccd
    }, {
      'upload': _0x2f6a6f['waUploadToServer']
    });
    const _0x432ac7 = generateWAMessageFromContent(_0x1c8a92, {
      'productMessage': {
        'product': {
          'productImage': _0x1c1ce5[_0x38c97b(0xa0)],
          'productId': '9999',
          'title': _0x4bb46b,
          'description': _0x1d59f9,
          'currencyCode': 'INR',
          'priceAmount1000': _0x38c97b(0xf7),
          'url': '' + websitex,
          'productImageCount': 0x1,
          'salePriceAmount1000': '0'
        },
        'businessOwnerJid': ownernumber + _0x38c97b(0x10b)
      }
    }, _0x495821);
    return _0x2f6a6f[_0x38c97b(0x126)](_0x1c8a92, _0x432ac7[_0x38c97b(0xa1)], {
      'messageId': _0x432ac7['key']['id']
    });
  };
  _0x2f6a6f[_0x5c1b54(0x12f)] = async (_0x55bd49, _0x5c97b1 = '', _0x1d7038 = '', _0x253f2b, _0x4ea064 = [], _0x38ed88 = {}) => {
    const _0x20b699 = _0x5c1b54;
    var _0x21be2d = generateWAMessageFromContent(_0x55bd49, proto[_0x20b699(0xd0)][_0x20b699(0x120)]({
      'templateMessage': {
        'hydratedTemplate': {
          'hydratedContentText': _0x5c97b1,
          'locationMessage': {
            'jpegThumbnail': _0x253f2b
          },
          'hydratedFooterText': _0x1d7038,
          'hydratedButtons': _0x4ea064
        }
      }
    }), _0x38ed88);
    _0x2f6a6f['relayMessage'](_0x55bd49, _0x21be2d[_0x20b699(0xa1)], {
      'messageId': _0x21be2d['key']['id']
    });
  };
  _0x2f6a6f[_0x5c1b54(0x108)] = async (_0x295204, _0x49e2aa, _0x5d50fd, _0x59d52a, _0x5cfbd0) => {
    const _0x3cf05b = _0x5c1b54;
    let _0x182b82 = Buffer['isBuffer'](_0x49e2aa) ? _0x49e2aa : /^data:.*?\/.*?;base64,/i[_0x3cf05b(0x12d)](_0x49e2aa) ? Buffer[_0x3cf05b(0xad)](_0x49e2aa[_0x3cf05b(0xe6)]`,`[0x1], _0x3cf05b(0xce)) : /^https?:\/\//['test'](_0x49e2aa) ? await await getBuffer(_0x49e2aa) : fs['existsSync'](_0x49e2aa) ? fs[_0x3cf05b(0xfd)](_0x49e2aa) : Buffer[_0x3cf05b(0xd1)](0x0);
    let _0x43e043 = {
      'image': _0x182b82,
      'jpegThumbnail': _0x182b82,
      'caption': _0x5d50fd,
      'fileLength': '1',
      'footer': _0x59d52a,
      'buttons': _0x5cfbd0,
      'headerType': 0x4
    };
    _0x2f6a6f[_0x3cf05b(0x83)](_0x295204, _0x43e043, {
      'quoted': m
    });
  };
  _0x2f6a6f[_0x5c1b54(0x77)] = async (_0x40e2a6, _0x2b77b4, _0x438bd1 = '', _0x5c1cdf = '', _0x24e878, _0x4cf1e7 = ![], _0x183bdf = {}) => {
    const _0x345149 = _0x5c1b54;
    let _0x3c9262 = await _0x2f6a6f[_0x345149(0xb5)](_0x2b77b4, !![]);
    let {
      res: _0x273ca4,
      data: _0x24238e,
      filename: _0x1edad5
    } = _0x3c9262;
    if (_0x273ca4 && _0x273ca4[_0x345149(0xb9)] !== 0xc8 || _0x24238e[_0x345149(0xa5)] <= 0x10000) {
      try {
        throw {
          'json': JSON[_0x345149(0xcc)](_0x24238e[_0x345149(0x79)]())
        };
      } catch (_0x31a76f) {
        if (_0x31a76f['json']) {
          throw _0x31a76f[_0x345149(0xa7)];
        }
      }
    }
    const _0xb8f29b = fs[_0x345149(0x137)](_0x1edad5)[_0x345149(0x132)] / 0x400 / 0x400;
    if (_0xb8f29b >= 0x708) {
      throw new Error('\x20The\x20file\x20size\x20is\x20too\x20large\x0a\x0a');
    }
    let _0xbb890e = {};
    if (_0x24e878) {
      _0xbb890e['quoted'] = _0x24e878;
    }
    if (!_0x3c9262) {
      _0x183bdf[_0x345149(0xfe)] = !![];
    }
    let _0x474afb = '';
    let _0xa09c2d = _0x183bdf[_0x345149(0xca)] || _0x3c9262[_0x345149(0xe2)];
    let _0x1f592e;
    if (/webp/[_0x345149(0x12d)](_0x3c9262[_0x345149(0xe2)]) || /image/[_0x345149(0x12d)](_0x3c9262[_0x345149(0xe2)]) && _0x183bdf[_0x345149(0xd2)]) {
      _0x474afb = _0x345149(0xeb);
    } else {
      if (/image/[_0x345149(0x12d)](_0x3c9262['mime']) || /webp/[_0x345149(0x12d)](_0x3c9262[_0x345149(0xe2)]) && _0x183bdf['asImage']) {
        _0x474afb = 'image';
      } else {
        if (/video/[_0x345149(0x12d)](_0x3c9262[_0x345149(0xe2)])) {
          _0x474afb = _0x345149(0x8e);
        } else {
          if (/audio/[_0x345149(0x12d)](_0x3c9262['mime'])) {
            _0x1f592e = await toAudio(_0x24238e, _0x3c9262['ext']);
            _0x24238e = _0x1f592e[_0x345149(0xa9)];
            _0x1edad5 = _0x1f592e[_0x345149(0xbd)];
            _0x474afb = _0x345149(0xb8);
            _0xa09c2d = _0x183bdf[_0x345149(0xca)] || _0x345149(0xf8);
          } else {
            _0x474afb = _0x345149(0xff);
          }
        }
      }
    }
    if (_0x183bdf['asDocument']) {
      _0x474afb = 'document';
    }
    delete _0x183bdf[_0x345149(0xd2)];
    delete _0x183bdf[_0x345149(0x71)];
    delete _0x183bdf[_0x345149(0xc5)];
    delete _0x183bdf[_0x345149(0xfe)];
    delete _0x183bdf[_0x345149(0x8a)];
    let _0xdcbd0d = {
      ..._0x183bdf,
      'caption': _0x5c1cdf,
      'ptt': _0x4cf1e7,
      [_0x474afb]: {
        'url': _0x1edad5
      },
      'mimetype': _0xa09c2d,
      'fileName': _0x438bd1 || _0x1edad5[_0x345149(0xe6)]('/')[_0x345149(0x9d)]()
    };
    let _0x48adca;
    try {
      _0x48adca = await _0x2f6a6f['sendMessage'](_0x40e2a6, _0xdcbd0d, {
        ..._0xbb890e,
        ..._0x183bdf
      });
    } catch (_0x2e90aa) {
      console[_0x345149(0xe7)](_0x2e90aa);
      _0x48adca = null;
    } finally {
      if (!_0x48adca) {
        _0x48adca = await _0x2f6a6f[_0x345149(0x83)](_0x40e2a6, {
          ..._0xdcbd0d,
          [_0x474afb]: _0x24238e
        }, {
          ..._0xbb890e,
          ..._0x183bdf
        });
      }
      _0x24238e = null;
      return _0x48adca;
    }
  };
  _0x2f6a6f[_0x5c1b54(0xaf)] = async (_0x57f035, _0x2c376c, _0x1db24f, _0x5c5717, _0x59d3cc = {}) => {
    const _0x2196d1 = _0x5c1b54;
    let _0x150be2 = '';
    let _0x42ce3c = await axios['head'](_0x2c376c);
    _0x150be2 = _0x42ce3c[_0x2196d1(0x10e)][_0x2196d1(0x117)];
    if (_0x150be2[_0x2196d1(0xe6)]('/')[0x1] === _0x2196d1(0x73)) {
      return _0x2f6a6f[_0x2196d1(0x83)](_0x57f035, {
        'video': await getBuffer(_0x2c376c),
        'caption': _0x1db24f,
        'gifPlayback': !![],
        ..._0x59d3cc
      }, {
        'quoted': _0x5c5717,
        ..._0x59d3cc
      });
    }
    let _0x352a2a = _0x150be2[_0x2196d1(0xe6)]('/')[0x0] + _0x2196d1(0xd0);
    if (_0x150be2 === _0x2196d1(0x119)) {
      return _0x2f6a6f[_0x2196d1(0x83)](_0x57f035, {
        'document': await getBuffer(_0x2c376c),
        'mimetype': _0x2196d1(0x119),
        'caption': _0x1db24f,
        ..._0x59d3cc
      }, {
        'quoted': _0x5c5717,
        ..._0x59d3cc
      });
    }
    if (_0x150be2[_0x2196d1(0xe6)]('/')[0x0] === _0x2196d1(0xc1)) {
      return _0x2f6a6f['sendMessage'](_0x57f035, {
        'image': await getBuffer(_0x2c376c),
        'caption': _0x1db24f,
        ..._0x59d3cc
      }, {
        'quoted': _0x5c5717,
        ..._0x59d3cc
      });
    }
    if (_0x150be2[_0x2196d1(0xe6)]('/')[0x0] === 'video') {
      return _0x2f6a6f[_0x2196d1(0x83)](_0x57f035, {
        'video': await getBuffer(_0x2c376c),
        'caption': _0x1db24f,
        'mimetype': _0x2196d1(0x100),
        ..._0x59d3cc
      }, {
        'quoted': _0x5c5717,
        ..._0x59d3cc
      });
    }
    if (_0x150be2['split']('/')[0x0] === _0x2196d1(0xb8)) {
      return _0x2f6a6f[_0x2196d1(0x83)](_0x57f035, {
        'audio': await getBuffer(_0x2c376c),
        'caption': _0x1db24f,
        'mimetype': _0x2196d1(0x12a),
        ..._0x59d3cc
      }, {
        'quoted': _0x5c5717,
        ..._0x59d3cc
      });
    }
  };
  _0x2f6a6f['sendPoll'] = (_0x2d45e6, _0x360cf7 = '', _0x5d329a = [], _0x51ad5f = 0x1) => {
    return _0x2f6a6f['sendMessage'](_0x2d45e6, {
      'poll': {
        'name': _0x360cf7,
        'values': _0x5d329a,
        'selectableCount': _0x51ad5f
      }
    });
  };
  return _0x2f6a6f;
}
function _0x4abd(_0x19e405, _0x591928) {
  const _0x31bb75 = _0x31bb();
  _0x4abd = function (_0x4abd33, _0x5c331d) {
    _0x4abd33 = _0x4abd33 - 0x6e;
    let _0x5106ab = _0x31bb75[_0x4abd33];
    return _0x5106ab;
  };
  return _0x4abd(_0x19e405, _0x591928);
}
NawBotz();
process['on']('uncaughtException', function (_0x300434) {
  const _0x3b388e = _0x1a6f9d;
  console[_0x3b388e(0x84)]('Caught\x20exception:\x20', _0x300434);
});