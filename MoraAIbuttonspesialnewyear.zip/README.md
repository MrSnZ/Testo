SC INI GERATIS !!!!   
jebeh di larang jual script iniii !!!!
kalau ada yg jual hubungi no di bawah !!!

rizal - dev

083119115977

.joingc https://chat.whatsapp.com/IWYixfay02cJwbzyo4XPH1

.joinch https://whatsapp.com/channel/0029Vaw0AGCEQIarHspllG1i